-- Bundler supplies Core, Defaults and playIntro; this file is the readable runtime body.
local environment = type(getgenv) == 'function' and getgenv() or _G
local supported = {
    [134196333708867] = 'Da Strike',
    [71324444457408] = 'Da Uphill',
    [139144803593140] = 'Da Downhill',
}
assert(supported[game.PlaceId], '[neoperro] This place is not supported.')
assert(type(environment.neoperro) == 'table', '[neoperro] Put the configuration above the runtime.')
local config = Core.merge(Defaults, environment.neoperro)
Core.validate(Defaults, config)
local Players = game:GetService('Players')
local RunService = game:GetService('RunService')
local Input = game:GetService('UserInputService')
local ReplicatedStorage = game:GetService('ReplicatedStorage')
local World = game:GetService('Workspace')
local localPlayer = Players.LocalPlayer
assert(localPlayer, '[neoperro] Run on the client.')
local mouse = localPlayer:GetMouse()
environment.__neoperroStartEpoch = (environment.__neoperroStartEpoch or 0) + 1
local startEpoch = environment.__neoperroStartEpoch
local playerGui = localPlayer:WaitForChild('PlayerGui', 5)
assert(playerGui, '[neoperro] PlayerGui unavailable.')
assert(environment.__neoperroStartEpoch == startEpoch, '[neoperro] A newer execution superseded this startup.')
local runtimeKey, hooksKey = '__neoperroRuntimeV1', '__neoperroHooksV1'
local previous = environment[runtimeKey]
if previous and previous.Intro then environment.__neoperroIntroSeenV1 = true end
local saved = previous and previous.Alive and type(previous.Snapshot) == 'function' and previous:Snapshot() or nil
if previous and type(previous.Destroy) == 'function' then previous:Destroy('replace') end

local state = {
    Alive = true, Version = '1.2.0', Config = config, Connections = {}, Objects = {},
    Records = {}, Toggles = {}, Held = {}, Locks = {}, Points = {}, Targets = {},
    Warnings = {}, Capabilities = {}, ShotUntil = 0, NextFire = 0, Initial = {},
    Whitelist = Core.ids(config.Whitelist.Players), WhiteMode = config.Whitelist.Mode,
    InitialWhitelist = Core.ids(config.Whitelist.Players), InitialWhiteMode = config.Whitelist.Mode,
    Epoch = 0, Visuals = {}, Focused = true, MacroInputs = {},
    Stats = {AimPackets = 0, Activations = 0, TriggerAttempts = 0, AmmoDrops = 0},
}
environment[runtimeKey] = state
local zero = Vector3.new(0, 0, 0)
local now = os.clock
local camera, cursor, cursorRay
local localCharacter, localHumanoid, localRoot, equipped, weaponName, muzzleAttachment
local tryMacro, releaseShotInput
local charConnections, toolConnections = {}, {}
local pendingTrigger, pendingPrefire, macro, activation
local renderName = 'neoperro.' .. tostring(now())
local featureNames = {'Silent Aim', 'Aim Assist', 'Triggerbot', 'ESP'}
local checkIndices = {['Silent Aim'] = 1, ['Aim Assist'] = 2, Triggerbot = 3}
local predictionKeys = {['Silent Aim'] = 'SilentAim', ['Aim Assist'] = 'AimAssist', Triggerbot = 'Triggerbot'}
local virtualInput
pcall(function() virtualInput = game:GetService('VirtualInputManager') end)

function state:Diagnose()
    local result = {Version = self.Version, Alive = self.Alive, Capabilities = Core.copy(self.Capabilities),
        Stats = Core.copy(self.Stats), Warnings = Core.copy(self.Warnings), Targets = {},
        MouseOwned = self.MouseOwned == true, ControlOwned = self.ControlOwned == true,
        Equipped = equipped and equipped.Name or nil, Remote = self.Remote and self.Remote.Name or nil}
    for name, player in pairs(self.Targets) do result.Targets[name] = player.UserId end
    return result
end

local function warnOnce(key, message)
    if state.Warnings[key] then return end
    state.Warnings[key] = message
    warn('[neoperro] ' .. message)
end

local function disconnect(list)
    for _, connection in ipairs(list) do connection:Disconnect() end
    for i = #list, 1, -1 do list[i] = nil end
end

local function connect(signal, callback, bucket)
    local connection = signal:Connect(function(...)
        if state.Alive then callback(...) end
    end)
    table.insert(bucket or state.Connections, connection)
    return connection
end

local function own(object)
    state.Objects[#state.Objects + 1] = object
    return object
end

local function make(class, props, parent)
    local object = Instance.new(class)
    for k, v in pairs(props) do object[k] = v end
    object.Parent = parent
    return object
end

local function validPlayer(id)
    return type(id) == 'number' and Players:GetPlayerByUserId(id) or nil
end

for _, name in ipairs(featureNames) do
    state.Initial[name] = config[name].Enabled == true
    state.Toggles[name] = state.Initial[name]
    if saved then state.Toggles[name] = Core.restoreToggle(state.Initial[name], saved.Initial[name], saved.Toggles[name]) end
    if saved and saved.Locks[name] and validPlayer(saved.Locks[name]) then state.Locks[name] = saved.Locks[name] end
end
if saved and config.Whitelist.Enabled then
    if Core.equal(state.InitialWhitelist, saved.InitialWhitelist) then state.Whitelist = Core.ids(saved.Whitelist) end
    if previous.Version == state.Version and state.InitialWhiteMode == saved.InitialWhiteMode then state.WhiteMode = saved.WhiteMode end
end

if not config.Whitelist.Enabled then state.Whitelist = {} end

function state:Snapshot()
    return Core.copy({Initial = self.Initial, Toggles = self.Toggles, Locks = self.Locks,
        Whitelist = self.Whitelist, WhiteMode = self.WhiteMode,
        InitialWhitelist = self.InitialWhitelist, InitialWhiteMode = self.InitialWhiteMode})
end

local function releaseControl()
    if state.ControlOwned then
        state.ControlOwned = false
        if virtualInput then pcall(function() virtualInput:SendKeyEvent(false, Enum.KeyCode.LeftControl, false, game) end) end
    end
end

local function cancelMacro()
    local old = macro
    macro = nil
    releaseControl()
    if old and old.tool and old.tool.Parent == localPlayer:FindFirstChildOfClass('Backpack')
        and localHumanoid and localHumanoid.Health > 0 and localCharacter
        and not localCharacter:FindFirstChildOfClass('Tool') then
        pcall(function() localHumanoid:EquipTool(old.tool) end)
    end
end

function state:Destroy(reason)
    if not self.Alive then return end
    self.Alive = false
    self.Points, self.Targets = {}, {}
    local hooks = environment[hooksKey]
    if hooks and hooks.Active == self then hooks.Active = nil end
    RunService:UnbindFromRenderStep(renderName)
    disconnect(self.Connections)
    disconnect(charConnections)
    disconnect(toolConnections)
    cancelMacro()
    if releaseShotInput then releaseShotInput() end
    if self.AutomatedTool then pcall(function() self.AutomatedTool:Deactivate() end) end
    for _, record in pairs(self.Records) do disconnect(record.connections); disconnect(record.characterConnections) end
    if self.Intro and self.Intro.Destroy then self.Intro:Destroy() end
    for visual in pairs(self.Visuals) do pcall(function() visual:Destroy() end) end
    for i = #self.Objects, 1, -1 do pcall(function() self.Objects[i]:Destroy() end) end
    if environment[runtimeKey] == self then environment[runtimeKey] = nil end
    if reason ~= 'replace' then print('[neoperro] Unloaded.') end
end

local function enabled(name)
    local feature = config[name]
    if not state.Toggles[name] then return false end
    local toggle = feature.Toggle
    if toggle and toggle.Enabled and toggle.Holding and not state.Held['toggle:' .. name] then return false end
    if name == 'Triggerbot' then
        local gate = feature.Activation
        if gate.Enabled and not state.Held['activation:Triggerbot'] then return false end
    end
    return true
end

local function typing()
    return not state.Focused or Input:GetFocusedTextBox() ~= nil
end

local function captureView()
    camera = World.CurrentCamera
    if not camera then return false end
    -- Viewport projections and IgnoreGuiInset overlays share the raw mouse coordinate space.
    cursor = Input:GetMouseLocation()
    cursorRay = camera:ViewportPointToRay(cursor.X, cursor.Y)
    return true
end

local function childValue(parent, name)
    local item = parent and parent:FindFirstChild(name)
    return item and item:IsA('ValueBase') and item.Value or nil
end

local function crew(player)
    local data = player:FindFirstChild('DataFolder')
    local information = data and data:FindFirstChild('Information')
    return childValue(information, 'Crew') or player:GetAttribute('Crew')
end

local function isKnocked(character)
    local effects = character:FindFirstChild('BodyEffects')
    return childValue(effects, 'K.O') == true or childValue(effects, 'Knocked') == true
        or character:GetAttribute('Knocked') == true or character:GetAttribute('K.O') == true
        or character:FindFirstChild('GRABBING_CONSTRAINT') ~= nil
end

local rayParams = RaycastParams.new()
rayParams.FilterType = Enum.RaycastFilterType.Exclude
rayParams.IgnoreWater = true
local function visible(point, character, origin, excludeTarget)
    if not camera or not Core.finiteVector(point) then return false end
    local exclusions = {camera}
    if localCharacter then exclusions[#exclusions + 1] = localCharacter end
    if excludeTarget and character then exclusions[#exclusions + 1] = character end
    rayParams.FilterDescendantsInstances = exclusions
    origin = origin or camera.CFrame.Position
    local direction = point - origin
    if direction.Magnitude < 0.001 then return true end
    local hit = World:Raycast(origin, direction, rayParams)
    return not hit or (not excludeTarget and character and hit.Instance:IsDescendantOf(character))
end

local function muzzle()
    if muzzleAttachment and muzzleAttachment.Parent then return muzzleAttachment.WorldPosition end
    local handle = equipped and equipped:FindFirstChild('Handle')
    if handle and handle:IsA('BasePart') then return handle.Position end
    return localRoot and localRoot.Position or (camera and camera.CFrame.Position)
end

local function partFor(record, name)
    local character = record.character
    if not character then return nil end
    local part = character:FindFirstChild(name)
    if not part and name == 'UpperTorso' then part = character:FindFirstChild('Torso') end
    return part and part:IsA('BasePart') and part or record.root
end

local function targetSettings(feature)
    return config[feature].Target or config['Silent Aim'].Target
end

local function cursorHit()
    rayParams.FilterDescendantsInstances = localCharacter and {localCharacter, camera} or {camera}
    return World:Raycast(cursorRay.Origin, cursorRay.Direction * 5000, rayParams)
end

local function targetPart(record, feature)
    if not record.character then return nil end
    local target = targetSettings(feature)
    if not target.Closest.Enabled then return partFor(record, target.BasePart) end
    local best, distance = nil, math.huge
    for _, part in ipairs(record.character:GetChildren()) do
        if part:IsA('BasePart') and part.Name ~= 'HumanoidRootPart' then
            local p, onScreen = camera:WorldToViewportPoint(part.Position)
            if onScreen and p.Z > 0 then
                local d = (Vector2.new(p.X, p.Y) - cursor).Magnitude
                if d < distance then best, distance = part, d end
            end
        end
    end
    return best or partFor(record, target.BasePart)
end

local function valid(record, feature, part, skipWall)
    if not record or record.player == localPlayer or record.player.Parent ~= Players then return false end
    local character, humanoid, root = record.character, record.humanoid, record.root
    if not character or not character.Parent or not humanoid or not root or not part or not part.Parent then return false end
    if not Core.finiteVector(part.Position) then return false end
    if not Core.whitelisted(config.Whitelist.Enabled, state.WhiteMode, state.Whitelist, record.player.UserId) then return false end
    local index = checkIndices[feature]
    local function check(key) return config.Checks[key] and config.Checks[key][index] == true end
    if check('Dead') and (humanoid.Health <= 0 or character:GetAttribute('Dead') == true) then return false end
    if check('Knocked') and isKnocked(character) then return false end
    if check('ForceField') and character:FindFirstChildOfClass('ForceField') then return false end
    if check('Tool') and not equipped then return false end
    if check('Crew') then
        local mine, theirs = crew(localPlayer), crew(record.player)
        if mine ~= nil and mine ~= '' and mine ~= '0' and mine ~= 0 and mine == theirs then return false end
    end
    if not skipWall and check('Wall') and not visible(part.Position, character) then return false end
    return true
end

local function velocity(record, feature)
    local raw = record.root.AssemblyLinearVelocity
    if not Core.finiteVector(raw) then raw = zero end
    if feature ~= 'Silent Aim' or config['Silent Aim'].EndMath.VelocityHistory then return Core.velocity(record.history, raw, zero) end
    return Core.limit(raw, 180)
end

local function playerBox(record, feature, standalone)
    if not record.root or not record.character then return nil end
    local style = config['2d-Box'][feature]
    local origin = record.root.Position
    if not standalone and style['Predicted Position'] then
        origin = origin + velocity(record, feature) * Core.number(config.Prediction[predictionKeys[feature]], 0.128, 0, 1)
    end
    local distance = (origin - (localRoot and localRoot.Position or camera.CFrame.Position)).Magnitude
    if distance > Core.number(standalone and config.ESP.MaxDistance or style['Max Distance'], 5050, 0, 100000) then return nil end
    local projected = camera:WorldToViewportPoint(origin)
    local width, height = Core.number(style.Size.Width, 5, 0.1, 100), Core.number(style.Size.Height, 4.3, 0.1, 100)
    if standalone then width, height = 6, 6 end
    local profile = not standalone and Core.profile(config['Gun Specifications'], weaponName, distance)
    if profile and profile.BoxSize then
        width = Core.number(profile.BoxSize[1], width, 0.1, 100)
        height = Core.number(profile.BoxSize[2], height, 0.1, 100)
    end
    local focal = camera.ViewportSize.Y / (2 * math.tan(math.rad(camera.FieldOfView) / 2))
    local x, y, w, h = Core.projectedBox(projected.X, projected.Y, projected.Z, width, height, focal)
    if not x or x+w < 0 or y+h < 0 or x > camera.ViewportSize.X or y > camera.ViewportSize.Y then return nil end
    return Vector2.new(x, y), Vector2.new(w, h)
end

local function inFov(record, feature, part)
    local settings = config[feature]
    if settings.Ignore then return true end
    if settings.Fov.Mode == '2d-Circle' then
        local p, onScreen = camera:WorldToViewportPoint(part.Position)
        if not onScreen or p.Z <= 0 then return false end
        return Core.fov(p.X - cursor.X, p.Y - cursor.Y, '2d-Circle', 0, 0,
            Core.number(settings.Fov['2d-Circle'].Size, 50, 1, 10000))
    end
    local position, size = playerBox(record, feature)
    return position ~= nil and cursor.X >= position.X and cursor.X <= position.X+size.X
        and cursor.Y >= position.Y and cursor.Y <= position.Y+size.Y
end

local function nearest(feature, assignment)
    if not captureView() then return nil end
    local choices = {}
    for _, record in pairs(state.Records) do
        local part = assignment and partFor(record, 'HumanoidRootPart') or targetPart(record, feature)
        if part and (assignment or (valid(record, feature, part, true) and inFov(record, feature, part))) then
            local projected, onScreen = camera:WorldToViewportPoint(part.Position)
            if projected.Z > 0 and (onScreen or (not assignment and config[feature].Ignore)) then
                local distance = (Vector2.new(projected.X, projected.Y) - cursor).Magnitude
                if not assignment or distance <= 150 then choices[#choices + 1] = {record = record, part = part, distance = distance} end
            end
        end
    end
    table.sort(choices, function(a, b) return a.distance < b.distance end)
    for _, choice in ipairs(choices) do
        if assignment or valid(choice.record, feature, choice.part) then return choice.record end
    end
end

local function aimPoint(record, feature)
    local settings = config[feature]
    local target = targetSettings(feature)
    local closest = target.Closest
    local part = targetPart(record, feature)
    if not valid(record, feature, part) then return nil end
    if (feature ~= 'Triggerbot' or settings.Fov.Enabled) and not inFov(record, feature, part) then return nil end
    local point = part.Position
    local exact = closest.Enabled and closest.Raycast and state.CursorHit
    if exact and exact.Instance:IsDescendantOf(record.character) and exact.Instance:IsA('BasePart') then
        part, point = exact.Instance, exact.Position
    elseif closest.Enabled and closest.Method == 'Point' then
        local depth = math.max(0, (point - cursorRay.Origin):Dot(cursorRay.Direction))
        local localPoint = part.CFrame:PointToObjectSpace(cursorRay.Origin + cursorRay.Direction * depth)
        local reduction = Core.number(closest.Reduce[closest.Axis == 'All' and 'All' or 'Center'], 0.7, 0, 1)
        local half = part.Size * (0.5 * (1 - reduction))
        localPoint = Vector3.new(
            closest.Axis == 'All' and math.clamp(localPoint.X, -half.X, half.X) or 0,
            math.clamp(localPoint.Y, -half.Y, half.Y),
            closest.Axis == 'All' and math.clamp(localPoint.Z, -half.Z, half.Z) or 0)
        record.pointState = record.pointState or {}
        local last = record.pointState[feature]
        if last and last.part == part then
            local alpha = Core.alpha(Core.number(closest.Sharpness, 0.65, 0.01, 1), now() - last.time)
            localPoint = last.point + (localPoint - last.point) * alpha
        end
        record.pointState[feature] = {part = part, point = localPoint, time = now()}
        point = part.CFrame:PointToWorldSpace(localPoint)
    end
    local leadTime = Core.number(config.Prediction[predictionKeys[feature]], 0.128, 0, 1)
    local vel = velocity(record, feature)
    local lead = vel * leadTime
    local ySettings = config['Y-Axis']
    if ySettings.Enabled and ySettings[predictionKeys[feature]] then
        local y = lead.Y
        if ySettings.Mode == 'Custom' then
            if vel.Y > 0 then y = y * Core.number(ySettings.JumpOffset, 1, 0, 5) end
        else
            local airborne = record.humanoid.FloorMaterial == Enum.Material.Air
            y = airborne and (vel.Y * leadTime - 0.5 * World.Gravity * leadTime * leadTime) or 0
            y = math.clamp(y, -part.Size.Y, part.Size.Y * 2)
        end
        lead = Vector3.new(lead.X, y, lead.Z)
    end
    point = point + lead
    -- Final Silent settings never reject camera assistance or independent trigger candidates.
    local anti = feature == 'Silent Aim' and settings.AntiCurve
    if anti and anti.Enabled then
        if anti.Mode == 'endmath' then
            local projected, onScreen = camera:WorldToViewportPoint(point)
            if not onScreen or projected.Z <= 0 or
                (Vector2.new(projected.X, projected.Y) - cursor).Magnitude > Core.number(anti.endmath.Radius, 120, 0, 10000) then return nil end
            if anti.endmath.WallCheck and not visible(point, record.character, muzzle(), true) then return nil end
        elseif anti.Mode == '3d-angles' then
            -- World-space interpretation; no unrequested angular rejection.
            if (point - mouse.Hit.Position).Magnitude > Core.number(anti['3d-angles'].Max, 2.2, 0, 10000) then return nil end
        end
    end
    if not Core.finiteVector(point) then return nil end
    if feature == 'Silent Aim' and settings.EndMath.WallCheck and
        (not visible(point, record.character, camera.CFrame.Position, true)
        or not visible(point, record.character, muzzle(), true)) then return nil end
    return point, part
end

local function selectTarget(feature)
    if not enabled(feature) or typing() then return nil end
    if config[feature].Mode == 'Auto' then
        if feature == 'Aim Assist' and config[feature]['Keybind Mode'].Holding and not state.Held['target:' .. feature] then return nil end
        return nearest(feature)
    end
    local mode = config[feature]['Keybind Mode']
    if mode.Holding and not state.Held['target:' .. feature] then return nil end
    local player = validPlayer(state.Locks[feature])
    return player and state.Records[player] or nil
end

local function updateAim()
    if not captureView() or not localHumanoid or localHumanoid.Health <= 0 then
        state.Points, state.Targets = {}, {}; return
    end
    state.CursorHit = cursorHit()
    for _, feature in ipairs({'Silent Aim', 'Aim Assist'}) do
        local record = selectTarget(feature)
        local point, part
        if record then point, part = aimPoint(record, feature) end
        state.Targets[feature] = point and record.player or nil
        state.Points[feature] = point
        if feature == 'Silent Aim' then state.AimPart = part end
    end
    state.ForwardPoint = camera.CFrame.Position + camera.CFrame.LookVector * 1000
    state.RawMousePoint = mouse.Hit.Position
end

-- One permanent pass-through dispatcher per metamethod; replacements only swap Active.
local hooks = environment[hooksKey]
if type(hooks) ~= 'table' then hooks = {}; environment[hooksKey] = hooks end
local function installHooks()
    local wrap = type(newcclosure) == 'function' and newcclosure or function(f) return f end
    if type(hookmetamethod) == 'function' and type(getnamecallmethod) == 'function' and not hooks.Namecall then
        local original
        local ok, result = pcall(function()
            return hookmetamethod(game, '__namecall', wrap(function(object, ...)
                local active = hooks.Active
                if active and active.Alive and object == active.Remote and getnamecallmethod() == 'FireServer' then
                    local args = table.pack(...)
                    if args[1] == 'MOUSE' and typeof(args[2]) == 'Vector3' and active.PacketPoint then
                        args[2] = active.PacketPoint
                        return original(object, table.unpack(args, 1, args.n))
                    end
                end
                return original(object, ...)
            end))
        end)
        if ok then original = result; hooks.Namecall = true else warnOnce('namecall', tostring(result)) end
    end
    if hooks.Namecall and type(hookmetamethod) == 'function' and type(checkcaller) == 'function' and not hooks.Index then
        local original
        local ok, result = pcall(function()
            return hookmetamethod(game, '__index', wrap(function(object, key)
                local active = hooks.Active
                if active and active.Alive and object == active.Mouse and not checkcaller()
                    and active.ClientPoint and os.clock() < active.ShotUntil then
                    if key == 'Hit' then return CFrame.new(active.ClientPoint) end
                    if key == 'Target' and active.AimPart then return active.AimPart end
                end
                return original(object, key)
            end))
        end)
        if ok then original = result; hooks.Index = true else warnOnce('index', tostring(result)) end
    end
    hooks.Active = state
    state.Mouse = mouse
    state.Capabilities.RemoteHook = hooks.Namecall == true
    state.Capabilities.ClientMouseHook = hooks.Index == true
end

local function refreshPacket()
    local point = state.Points['Silent Aim']
    local shooting = now() < state.ShotUntil or (not typing() and Input:IsMouseButtonPressed(Enum.UserInputType.MouseButton1))
    if state.ForcedPoint and now() < state.ForcedUntil then point = state.ForcedPoint end
    state.PacketPoint = nil
    if equipped and enabled('Silent Aim') and not typing() then
        if config['Anti-AimViewer'].Enabled and not shooting then state.PacketPoint = nil
        else state.PacketPoint = point end
    end
    if shooting and state.ForcedPoint and now() < state.ForcedUntil then state.PacketPoint = state.ForcedPoint end
    state.ClientPoint = config['Client Bullets'].Enabled and (point or state.Points['Aim Assist']) or nil
    -- Keep the local-visual hook from turning camera-only assistance into silent aim.
    if shooting and state.ClientPoint and not state.PacketPoint then state.PacketPoint = state.RawMousePoint end
end

local function sendAim(point)
    if not point or not state.Remote then return end
    state.PacketPoint = point
    state.Stats.AimPackets = state.Stats.AimPackets + 1
    local ok, reason = pcall(function() state.Remote:FireServer('MOUSE', point) end)
    if not ok then warnOnce('remote-send', tostring(reason)) end
end

local function macroEnabled()
    local supplied = environment.neoperro
    local live = type(supplied) == 'table' and supplied.Misc and supplied.Misc['Macro Abuse']
    return state.Alive and config.Misc['Macro Abuse'].Enabled == true and type(live) == 'table' and live.Enabled == true
end

local function detectedMacro()
    local moving = localHumanoid and localHumanoid.MoveDirection.Magnitude > 0.05
    return Core.macroActive(state.MacroInputs, now(), moving)
end

local function beginMacro(source, tool, confirmed)
    local settings = config.Misc['Macro Abuse']
    if not macroEnabled() or macro or (source ~= 'Manual' and source ~= 'Triggerbot') then return end
    if source == 'Triggerbot' and not settings['Work With TB'] then return end
    if settings['Macro Check'] and not detectedMacro() then return end
    if settings['Check Ammo'] and not confirmed then
        local ammo = childValue(tool, 'Ammo')
        if type(ammo) ~= 'number' then warnOnce('macro-ammo', 'Macro Check Ammo is on, but this tool has no replicated Ammo value.'); return end
        local drop = state.LastAmmoDrop
        if not drop or drop.consumed or drop.tool ~= tool or now() - drop.time > 0.2 then
            state.PendingMacro = {source = source, tool = tool, expires = now() + 0.65}
            return
        end
    end
    state.PendingMacro = nil
    if not virtualInput then warnOnce('macro-input', 'Macro needs VirtualInputManager key events.'); return end
    if not localHumanoid or localHumanoid.Health <= 0 or typing() then return end
    if settings['Check Ammo'] and state.LastAmmoDrop then state.LastAmmoDrop.consumed = true end
    macro = {stage = 'wait', due = now() + 0.04, tool = tool, character = localCharacter}
end
tryMacro = beginMacro

local function macroStep(time)
    if not macro then return end
    local cycle = macro
    if not macroEnabled() or (config.Misc['Macro Abuse']['Macro Check'] and not detectedMacro()) or typing() or localCharacter ~= cycle.character
        or not localHumanoid or localHumanoid.Health <= 0 or not cycle.tool.Parent then cancelMacro(); return end
    if time < cycle.due then return end
    if cycle.stage == 'wait' then
        if cycle.tool ~= equipped then cancelMacro(); return end
        localHumanoid:UnequipTools()
        cycle.stage, cycle.due = 'crouch', time + 0.06
    elseif cycle.stage == 'crouch' then
        -- Never release a Ctrl key the user was already holding.
        if not Input:IsKeyDown(Enum.KeyCode.LeftControl) and not Input:IsKeyDown(Enum.KeyCode.RightControl) then
            local ok = pcall(function() virtualInput:SendKeyEvent(true, Enum.KeyCode.LeftControl, false, game) end)
            if not ok then warnOnce('macro-denied', 'This executor cannot send Ctrl input.'); cancelMacro(); return end
            state.ControlOwned = true
        end
        cycle.stage, cycle.due = 'equip', time + 0.07
    elseif cycle.stage == 'equip' then
        if localCharacter:FindFirstChildOfClass('Tool') then cancelMacro(); return end
        if cycle.tool.Parent ~= localPlayer:FindFirstChildOfClass('Backpack') then cancelMacro(); return end
        localHumanoid:EquipTool(cycle.tool)
        cycle.stage, cycle.due = 'release', time + 0.07
    else releaseControl(); macro = nil end
end

releaseShotInput = function(preserveShot)
    if state.ShotRelease then
        local release = state.ShotRelease
        state.ShotRelease = nil
        pcall(release)
    end
    state.MouseOwned = false
    if not preserveShot then
        state.ForcedPoint, state.ForcedUntil = nil, nil
        state.FiringRecord, state.FiringSource, state.FiringTool = nil, nil, nil
        activation = nil
    end
    if state.AutomatedTool then pcall(function() state.AutomatedTool:Deactivate() end) end
    state.AutomatedTool = nil
end

local function fire(source, record, point)
    if state.ShotRelease or state.AutomatedTool then return false end
    if not equipped or not equipped.Enabled or macro or typing() or now() < state.NextFire then return false end
    if Input:IsMouseButtonPressed(Enum.UserInputType.MouseButton1) and not state.MouseOwned then return false end
    if not localHumanoid or localHumanoid.Health <= 0 or isKnocked(localCharacter) then return false end
    local ammo = childValue(equipped, 'Ammo')
    if type(ammo) == 'number' and ammo <= 0 then return false end
    local time, tool = now(), equipped
    state.NextFire, state.ShotUntil = time + 0.08, time + 0.14
    state.ForcedPoint, state.ForcedUntil = point, time + 0.14
    activation = {source = source, tool = tool, untilTime = time + 0.14, sent = true}
    state.Stats.TriggerAttempts = state.Stats.TriggerAttempts + 1
    sendAim(point)
    state.DeactivateAt = time + (source == 'Triggerbot' and Core.delay(config.Triggerbot, (record.root.Position - muzzle()).Magnitude, state.TriggerRandom or 0.5) or 0.04)
    state.ForcedUntil = math.max(state.ForcedUntil, state.DeactivateAt + 0.05)
    state.ShotUntil = state.ForcedUntil
    activation.untilTime = state.ForcedUntil
    state.FiringRecord, state.FiringSource, state.FiringTool = record, source, tool
    if type(mouse1press) == 'function' and type(mouse1release) == 'function' then
        state.MouseOwned = true
        state.ShotRelease = mouse1release
        local ok = pcall(mouse1press)
        if ok then state.Capabilities.FireInput = 'mouse1press'; return true end
        releaseShotInput(true)
    end
    if virtualInput then
        state.MouseOwned = true
        local screen = Input:GetMouseLocation()
        local x, y = screen.X, screen.Y
        state.ShotRelease = function() virtualInput:SendMouseButtonEvent(x, y, 0, false, game, 0) end
        local ok = pcall(function() virtualInput:SendMouseButtonEvent(x, y, 0, true, game, 0) end)
        if ok then state.Capabilities.FireInput = 'VirtualInputManager'; return true end
        releaseShotInput(true)
    end
    state.AutomatedTool = tool
    local ok, reason = pcall(function() tool:Activate() end)
    state.Capabilities.FireInput = 'Tool.Activate fallback'
    if not ok then releaseShotInput(); warnOnce('activate', tostring(reason)); return false end
    return true
end

local function activated(tool)
    if tool ~= equipped or typing() then return end
    local source = 'Manual'
    if state.FiringTool == tool and (state.MouseOwned or state.AutomatedTool) then source = state.FiringSource
    elseif activation and activation.tool == tool and now() <= activation.untilTime then source = activation.source end
    activation = nil
    state.Stats.Activations = state.Stats.Activations + 1
    state.ShotUntil = now() + 0.14
    updateAim()
    refreshPacket()
    if source == 'Manual' and enabled('Silent Aim') then sendAim(state.Points['Silent Aim']) end
    state.LastShot = {time = now(), tool = tool, origin = muzzle(), point = state.ClientPoint}
    beginMacro(source, tool)
end

local function bindTool(tool)
    if not tool:IsA('Tool') then return end
    local name = Core.weapon(tool.Name)
    local lower = tool.Name:lower()
    if lower:find('wallet') or lower:find('phone') or lower:find('knife') or lower:find('katana') then return end
    if not name and not tool:FindFirstChild('Ammo') and not tool:FindFirstChild('Handle') then return end
    releaseShotInput()
    disconnect(toolConnections)
    equipped, weaponName, muzzleAttachment = tool, name, nil
    for _, item in ipairs(tool:GetDescendants()) do
        if item:IsA('Attachment') and (item.Name:lower():find('muzzle') or item.Name == 'GunAttachment') then muzzleAttachment = item; break end
    end
    local ammoValue = tool:FindFirstChild('Ammo')
    if ammoValue and (ammoValue:IsA('IntValue') or ammoValue:IsA('NumberValue')) then
        local previousAmmo = ammoValue.Value
        connect(ammoValue:GetPropertyChangedSignal('Value'), function()
            local value = ammoValue.Value
            if value < previousAmmo then
                state.Stats.AmmoDrops = state.Stats.AmmoDrops + 1
                state.LastAmmoDrop = {tool = tool, time = now()}
                local pending = state.PendingMacro
                if pending and pending.tool == tool and now() <= pending.expires then tryMacro(pending.source, tool, true) end
            end
            previousAmmo = value
        end, toolConnections)
    end
    connect(tool.Activated, function() activated(tool) end, toolConnections)
    connect(tool.AncestryChanged, function()
        if tool.Parent ~= localCharacter and equipped == tool then
            releaseShotInput()
            equipped, weaponName, muzzleAttachment = nil, nil, nil
            state.PendingMacro = nil
            state.PacketPoint, state.ClientPoint = nil, nil
            pendingTrigger, pendingPrefire = nil, nil
            disconnect(toolConnections)
        end
    end, toolConnections)
end

local function bindCharacter(character)
    releaseShotInput()
    cancelMacro()
    disconnect(charConnections); disconnect(toolConnections)
    localCharacter, localHumanoid, localRoot = character, nil, nil
    equipped, weaponName = nil, nil
    pendingTrigger, pendingPrefire, activation = nil, nil, nil
    state.LastLocalVelocity, state.LastShot = nil, nil
    state.PendingMacro, state.MacroInputs, state.LastAmmoDrop = nil, {}, nil
    local function added(child)
        if child:IsA('Humanoid') then localHumanoid = child
        elseif child.Name == 'HumanoidRootPart' and child:IsA('BasePart') then localRoot = child
        elseif child:IsA('Tool') then bindTool(child) end
    end
    for _, child in ipairs(character:GetChildren()) do added(child) end
    connect(character.ChildAdded, added, charConnections)
    connect(character.ChildRemoved, function(child)
        if child == localHumanoid then localHumanoid = nil end
        if child == localRoot then localRoot = nil end
    end, charConnections)
end

local function prefireActive()
    local settings = config.Misc.Prefire
    return settings.Enabled and not typing() and (settings.Holding and state.Held.prefire or (not settings.Holding and state.PrefireToggle))
end

local function opponentShot(record)
    local settings = config.Misc.Prefire
    if not prefireActive() or not localRoot or not equipped or not record.root then return end
    if (record.root.Position - localRoot.Position).Magnitude > Core.number(settings.Range, 100, 0, 5000) then return end
    if not pendingPrefire then
        pendingPrefire = {record = record, tool = equipped, due = now() + Core.number(settings.Delay, 0.25, 0, 10)}
    end
end

local function bindOpponent(record, character)
    disconnect(record.characterConnections)
    record.character, record.root, record.humanoid, record.history = character, nil, nil, {}
    record.bounds, record.boundsAt, record.visibilityAt = nil, nil, nil
    record.pointState = {}
    record.lastAmmo, record.ammoTool = nil, nil
    local function added(item)
        if item.Name == 'HumanoidRootPart' and item:IsA('BasePart') then record.root = item end
        if item:IsA('Humanoid') then record.humanoid = item end
    end
    for _, item in ipairs(character:GetChildren()) do added(item) end
    connect(character.ChildAdded, added, record.characterConnections)
    connect(character.ChildRemoved, function(item)
        if item == record.root then record.root = nil; record.history = {} end
        if item == record.humanoid then record.humanoid = nil end
    end, record.characterConnections)
end

local function observeAmmo(record)
    if not record.character then return end
    local tool = record.character:FindFirstChildOfClass('Tool')
    local ammo = tool and childValue(tool, 'Ammo')
    if type(ammo) == 'number' then
        if tool == record.ammoTool and record.lastAmmo and ammo < record.lastAmmo then opponentShot(record) end
        record.lastAmmo = ammo
        state.Capabilities.ReplicatedAmmo = true
    else record.lastAmmo = nil end
    record.ammoTool = tool
end

local function addPlayer(player)
    if player == localPlayer or state.Records[player] then return end
    local record = {player = player, connections = {}, characterConnections = {}, history = {}}
    state.Records[player] = record
    connect(player.CharacterAdded, function(character) bindOpponent(record, character) end, record.connections)
    connect(player.CharacterRemoving, function()
        disconnect(record.characterConnections)
        record.character, record.root, record.humanoid, record.history = nil, nil, nil, {}
    end, record.connections)
    if player.Character then bindOpponent(record, player.Character) end
end

local function triggerCandidate()
    if not enabled('Triggerbot') or typing() or not equipped or not captureView() then return nil end
    state.CursorHit = cursorHit()
    local record
    if config.Triggerbot.Fov.Enabled then record = nearest('Triggerbot')
    else
        local object, player = mouse.Target or (state.CursorHit and state.CursorHit.Instance), nil
        if not object then return nil end
        while object and object ~= World do
            if object:IsA('Model') then player = Players:GetPlayerFromCharacter(object); if player then break end end
            object = object.Parent
        end
        record = player and state.Records[player]
    end
    if not record then return nil end
    if config.Triggerbot.TargetOnly and record.player ~= state.Targets['Silent Aim'] then return nil end
    local point = aimPoint(record, 'Triggerbot')
    if point then return record, point end
end

local random = Random.new()
local function automaticFire(time)
    local record, point = triggerCandidate()
    state.Targets.Triggerbot = record and record.player or nil
    state.Points.Triggerbot = point
    -- Looten presses immediately, holds for Delay, then releases. Never overlap cycles.
    if state.FiringSource == 'Triggerbot' and (not record or record ~= state.FiringRecord or equipped ~= state.FiringTool) then releaseShotInput() end
    if record and state.FiringRecord == record and state.FiringSource == 'Triggerbot' then state.ForcedPoint = point end
    if record then state.TriggerRandom = random:NextNumber(); fire('Triggerbot', record, point) end
    if pendingPrefire then
        local shot = pendingPrefire
        if not prefireActive() or equipped ~= shot.tool or not shot.record.root or not localRoot
            or (shot.record.root.Position - localRoot.Position).Magnitude > Core.number(config.Misc.Prefire.Range, 100, 0, 5000) then
            pendingPrefire = nil
        elseif time >= shot.due then
            pendingPrefire = nil
            local aim = aimPoint(shot.record, 'Triggerbot')
            if aim then fire('Prefire', shot.record, aim) end
        end
    end
end

-- Drawing is optional. Native GUI fallback keeps feature behavior available.
local gui = own(make('ScreenGui', {Name = 'NeoperroOverlay', ResetOnSpawn = false, IgnoreGuiInset = true,
    DisplayOrder = 9000, ZIndexBehavior = Enum.ZIndexBehavior.Sibling}, playerGui))
local function visual(kind)
    local wrapper = {}
    local drawable
    if Drawing and type(Drawing.new) == 'function' then
        local ok, result = pcall(Drawing.new, kind)
        if ok then drawable = result end
    end
    if drawable then
        drawable.Visible = false
        if kind == 'Circle' then drawable.NumSides = 64 end
        if kind ~= 'Text' then drawable.Thickness = 1; drawable.Filled = false end
        if kind == 'Text' then drawable.Size = 13; drawable.Center = true; drawable.Outline = true end
        function wrapper:Set(p) for k, v in pairs(p) do drawable[k] = v end end
        function wrapper:Destroy() drawable:Remove() end
    else
        local obj = make(kind == 'Text' and 'TextLabel' or 'Frame', {
            Visible = false, BorderSizePixel = 0, BackgroundTransparency = 1,
        }, gui)
        local stroke
        if kind == 'Text' then
            obj.BackgroundTransparency = 1; obj.Font = Enum.Font.Code; obj.TextSize = 13
            obj.TextStrokeTransparency = 0.2; obj.AnchorPoint = Vector2.new(0.5, 0)
            obj.Size = UDim2.fromOffset(240, 18)
        else
            stroke = make('UIStroke', {Thickness = 1, ApplyStrokeMode = Enum.ApplyStrokeMode.Border}, obj)
            if kind == 'Circle' then make('UICorner', {CornerRadius = UDim.new(1, 0)}, obj) end
        end
        local props = {Transparency = 1, Filled = false, Radius = 1, Color = Color3.new(1, 1, 1)}
        function wrapper:Set(p)
            for k, v in pairs(p) do props[k] = v end
            if p.Visible ~= nil then obj.Visible = p.Visible end
            if props.Position then
                local offset = kind == 'Circle' and props.Radius or 0
                obj.Position = UDim2.fromOffset(props.Position.X - offset, props.Position.Y - offset)
            end
            if kind == 'Text' then
                if p.Text then obj.Text = p.Text end
                obj.TextColor3 = props.Color; obj.TextTransparency = 1 - props.Transparency
                obj.TextStrokeTransparency = 1 - props.Transparency * 0.8
            else
                local size = kind == 'Circle' and Vector2.new(props.Radius * 2, props.Radius * 2) or props.Size
                if size then obj.Size = UDim2.fromOffset(size.X, size.Y) end
                obj.BackgroundColor3 = props.Color
                obj.BackgroundTransparency = props.Filled and 1 - props.Transparency or 1
                stroke.Color = props.Color; stroke.Transparency = 1 - props.Transparency
                stroke.Thickness = props.Thickness or 1
            end
        end
        function wrapper:Destroy() obj:Destroy() end
    end
    state.Visuals[wrapper] = true
    return wrapper
end

local fovVisuals, debugVisuals = {}, {}
for _, name in ipairs({'Silent Aim', 'Aim Assist', 'Triggerbot'}) do
    fovVisuals[name] = {box = visual('Square'), circle = visual('Circle')}
    debugVisuals[name] = visual('Circle')
end

local function color(rgb)
    return Color3.fromRGB(Core.number(rgb[1], 255, 0, 255), Core.number(rgb[2], 255, 0, 255), Core.number(rgb[3], 255, 0, 255))
end

local function drawFov()
    for name, shapes in pairs(fovVisuals) do
        local fov = config[name].Fov
        local circle = fov['2d-Circle']
        shapes.box:Set({Visible = false})
        shapes.circle:Set({Visible = enabled(name) and (name ~= 'Triggerbot' or fov.Enabled) and fov.Mode == '2d-Circle' and circle.Visible == true,
            Position = cursor, Radius = Core.number(circle.Size, 50, 1, 10000), Color = color(circle.Color), Transparency = 1})
        local point = state.Points[name]
        local projected, onScreen
        if point then projected, onScreen = camera:WorldToViewportPoint(point) end
        debugVisuals[name]:Set({Visible = name == 'Silent Aim' and config['Silent Aim'].EndMath.Visualizer and onScreen == true,
            Position = projected and Vector2.new(projected.X, projected.Y) or cursor,
            Radius = 3, Filled = true, Color = Color3.new(1, 1, 1), Transparency = 1})
    end
end

local function assignedColor(id, fallback)
    if not config.Whitelist.Enabled then return fallback end
    for _, assigned in ipairs(state.Whitelist) do
        if assigned == id then return state.WhiteMode == 'Target' and Color3.fromRGB(255, 75, 75) or Color3.fromRGB(80, 230, 110) end
    end
    return fallback
end

local function drawPlayers(time)
    for _, record in pairs(state.Records) do
        local ok, reason = pcall(function()
            local exists = record.root and record.humanoid and record.character and record.character.Parent
            local dead = exists and (record.humanoid.Health <= 0 or record.character:GetAttribute('Dead') == true)
            for _, feature in ipairs({'Silent Aim', 'Aim Assist', 'Triggerbot'}) do
                local style = config['2d-Box'][feature]
                local standalone = feature == 'Silent Aim' and not style.Visible
                local show = exists and enabled('ESP') and (style.Visible or standalone)
                if dead and (config.ESP.DeadCheck or config.Checks.Dead[checkIndices[feature]]) then show = false end
                if show then show = (record.root.Position - camera.CFrame.Position).Magnitude <= Core.number(config.ESP.MaxDistance, 5050, 0, 100000) end
                if show and config.ESP.VisibleCheck then
                    if time >= (record.visibilityAt or 0) then
                        record.espVisible, record.visibilityAt = visible(record.root.Position, record.character), time + 0.08
                    end
                    show = record.espVisible
                end
                local position, size
                if show then position, size = playerBox(record, feature, standalone) end
                record.visuals = record.visuals or {}
                local v = record.visuals[feature]
                if position then
                    if not v then v = {outline = visual('Square'), box = visual('Square'), name = visual('Text')}; record.visuals[feature] = v end
                    local opacity = Core.number(style.Transparency, 1, 0, 1)
                    local foreground = assignedColor(record.player.UserId, color(style.Color.Box[1]))
                    v.outline:Set({Visible = true, Position = position, Size = size, Thickness = 3, Filled = false,
                        Color = color(style.Color.Box[2]), Transparency = opacity})
                    v.box:Set({Visible = true, Position = position, Size = size, Filled = style.Filled == true,
                        Color = foreground, Transparency = opacity})
                    local name = style.Name[2] == 'Name' and record.player.Name
                        or (style.Name[2] == 'UserId' and tostring(record.player.UserId) or record.player.DisplayName)
                    v.name:Set({Visible = config.ESP.Names and style.Name[1], Text = name,
                        Position = Vector2.new(position.X + size.X / 2, position.Y - 17), Color = foreground, Transparency = opacity})
                elseif v then for _, object in pairs(v) do object:Set({Visible = false}) end end
            end
        end)
        if not ok then
            if record.visuals then for _, group in pairs(record.visuals) do for _, v in pairs(group) do pcall(function() v:Set({Visible = false}) end) end end end
            warnOnce('draw-player:' .. tostring(record.player.UserId), tostring(reason))
        end
    end
end

local function inputMatches(input, action)
    return action and Core.input(action.Keybind, input.KeyCode.Name, input.UserInputType.Name)
end

local function inputChanged(input, began, processed)
    if state.MouseOwned and input.UserInputType == Enum.UserInputType.MouseButton1 then return end
    if began and not typing() and (input.KeyCode.Name == 'I' or input.KeyCode.Name == 'O') then
        Core.observeMacro(state.MacroInputs, input.KeyCode.Name == 'I' and 1 or -1, now())
    end
    if began and (processed or typing()) then return end
    if began and config.Misc.Panic.Enabled and inputMatches(input, config.Misc.Panic) then state:Destroy('panic'); return end
    if began and input.UserInputType == Enum.UserInputType.MouseButton1 and equipped then
        state.ShotUntil = now() + 0.14; updateAim(); refreshPacket(); sendAim(state.Points['Silent Aim'])
    end
    for _, name in ipairs(featureNames) do
        local toggle = config[name].Toggle
        if toggle.Enabled and inputMatches(input, toggle) then
            if toggle.Holding then state.Held['toggle:' .. name] = began
            elseif began then state.Toggles[name] = not state.Toggles[name] end
        end
    end
    for _, name in ipairs({'Silent Aim', 'Aim Assist'}) do
        local mode = config[name]['Keybind Mode']
        if inputMatches(input, mode) then
            state.Held['target:' .. name] = began
        end
        if config[name].Mode == 'Target' and inputMatches(input, mode) then
            if mode.Holding then
                state.Held['target:' .. name] = began
                if not began then state.Locks[name] = nil end
            end
            if began then
                if not mode.Holding and mode['Unlock Mode'] == 'Normal' and state.Locks[name] then state.Locks[name] = nil
                else local record = nearest(name); state.Locks[name] = record and record.player.UserId or nil end
            end
        end
    end
    local activationKey = config.Triggerbot.Activation
    if activationKey.Enabled and inputMatches(input, activationKey) then
        if activationKey.Holding then state.Held['activation:Triggerbot'] = began
        elseif began then state.Held['activation:Triggerbot'] = not state.Held['activation:Triggerbot'] end
    end
    if inputMatches(input, config.Misc.Prefire) then
        if config.Misc.Prefire.Holding then state.Held.prefire = began
        elseif began then state.PrefireToggle = not state.PrefireToggle end
    end
    if began then
        if config.Whitelist.Enabled and inputMatches(input, config.Whitelist.AssignKey) then
            local record = nearest('Silent Aim', true)
            if record then
                local id, found = record.player.UserId, nil
                for i, value in ipairs(state.Whitelist) do if value == id then found = i; break end end
                if found then table.remove(state.Whitelist, found)
                elseif #state.Whitelist < 4 then state.Whitelist[#state.Whitelist + 1] = id end
            end
        end
    end
    if state.FiringSource == 'Triggerbot' and not enabled('Triggerbot') then releaseShotInput() end
    refreshPacket()
end

local function antiFling()
    if not config.Misc.AntiFling or not localRoot or not localHumanoid or localHumanoid.Health <= 0 then return end
    local linear, angular = localRoot.AssemblyLinearVelocity, localRoot.AssemblyAngularVelocity
    local last = state.LastLocalVelocity
    if last and linear.Magnitude > 180 and angular.Magnitude > 40 and (linear - last).Magnitude > 120 then
        localRoot.AssemblyLinearVelocity = Core.limit(last, 60)
        localRoot.AssemblyAngularVelocity = zero
    end
    state.LastLocalVelocity = linear.Magnitude < 180 and linear or zero
end

-- Recognize only tracer-like Beams near this player's most recent shot.
-- Ownership cannot be inferred for arbitrary effects; leave unmatched effects alone.
local beamEdits = {}
local function inspectBeam(beam)
    if not state.Alive or not config['Client Bullets'].Enabled or not beam:IsA('Beam') then return end
    local shot = state.LastShot
    if not shot or now() - shot.time > 0.18 or not shot.point or not shot.origin then return end
    local a, b = beam.Attachment0, beam.Attachment1
    if not a or not b then return end
    local parentName = beam.Parent and beam.Parent.Name:lower() or ''
    local label = beam.Name:lower() .. parentName
    if not (label:find('gun') or label:find('bullet') or label:find('tracer')) then return end
    if (a.WorldPosition - shot.origin).Magnitude > 6 then return end
    local previousPosition, target = b.Position, shot.point
    b.WorldPosition = target
    beamEdits[#beamEdits + 1] = {attachment = b, old = previousPosition, written = b.Position, expires = now() + 0.3}
end

local function restoreBeams(all)
    for i = #beamEdits, 1, -1 do
        local edit = beamEdits[i]
        if all or now() >= edit.expires or not edit.attachment.Parent then
            if edit.attachment.Parent and edit.attachment.Position == edit.written then edit.attachment.Position = edit.old end
            table.remove(beamEdits, i)
        end
    end
end

local originalDestroy = state.Destroy
function state:Destroy(reason)
    restoreBeams(true)
    originalDestroy(self, reason)
end

local function findRemote()
    local remote = ReplicatedStorage:FindFirstChild('MAINEVENT') or ReplicatedStorage:FindFirstChild('MainEvent')
    state.Remote = remote and remote:IsA('RemoteEvent') and remote or nil
    state.Capabilities.Remote = state.Remote ~= nil
end

local function start()
    findRemote()
    installHooks()
    if not state.Remote then warnOnce('missing-remote', 'MAINEVENT is missing; firing redirection waits for it to appear.') end
    if not hooks.Namecall then warnOnce('no-hook', 'Namecall hooks unavailable: using Looten-style activation updates; Anti-AimViewer is unavailable.') end
    if not hooks.Index then warnOnce('no-index', 'Mouse hooks unavailable: local bullet redirection is limited to recognized Beams.') end
    connect(ReplicatedStorage.ChildAdded, function(child) if child.Name == 'MAINEVENT' or child.Name == 'MainEvent' then findRemote() end end)
    connect(ReplicatedStorage.ChildRemoved, function(child) if child == state.Remote then findRemote() end end)
    connect(localPlayer.CharacterAdded, bindCharacter)
    connect(localPlayer.CharacterRemoving, function()
        releaseShotInput(); cancelMacro(); disconnect(charConnections); disconnect(toolConnections)
        localCharacter, localHumanoid, localRoot, equipped, weaponName = nil, nil, nil, nil, nil
        state.PacketPoint, state.ClientPoint, state.Points, state.Targets = nil, nil, {}, {}
        pendingTrigger, pendingPrefire = nil, nil
    end)
    if localPlayer.Character then bindCharacter(localPlayer.Character) end
    for _, player in ipairs(Players:GetPlayers()) do addPlayer(player) end
    connect(Players.PlayerAdded, addPlayer)
    connect(Players.PlayerRemoving, function(player)
        local record = state.Records[player]
        if record then
            disconnect(record.connections); disconnect(record.characterConnections)
            if record.visuals then for _, group in pairs(record.visuals) do for _, v in pairs(group) do v:Destroy(); state.Visuals[v] = nil end end end
            state.Records[player] = nil
        end
        for name, id in pairs(state.Locks) do if id == player.UserId then state.Locks[name] = nil end end
    end)
    connect(Input.InputBegan, function(input, processed) inputChanged(input, true, processed) end)
    connect(Input.InputEnded, function(input) inputChanged(input, false, false) end)
    connect(Input.InputChanged, function(input)
        if not typing() and input.UserInputType == Enum.UserInputType.MouseWheel and input.Position.Z ~= 0 then
            Core.observeMacro(state.MacroInputs, input.Position.Z > 0 and 1 or -1, now())
        end
    end)
    local function suspend()
        state.Held = {}; state.Points = {}; state.Targets = {}
        state.PacketPoint, state.ClientPoint = nil, nil
        pendingTrigger, pendingPrefire = nil, nil
        state.PendingMacro, state.MacroInputs = nil, {}
        cancelMacro(); releaseShotInput()
        if state.AutomatedTool then pcall(function() state.AutomatedTool:Deactivate() end); state.AutomatedTool = nil end
    end
    connect(Input.WindowFocusReleased, function() state.Focused = false; suspend() end)
    connect(Input.WindowFocused, function() state.Focused = true end)
    connect(Input.TextBoxFocused, suspend)
    connect(localPlayer.Idled, function()
        if config.Misc.AntiAfk then
            local ok, reason = pcall(function() local virtualUser = game:GetService('VirtualUser')
                virtualUser:CaptureController()
                local view = World.CurrentCamera
                if view then
                    virtualUser:Button2Down(Vector2.new(0, 0), view.CFrame)
                    virtualUser:Button2Up(Vector2.new(0, 0), view.CFrame)
                end end)
            if not ok then warnOnce('idle', 'AntiAfk unavailable: ' .. tostring(reason)) end
        end
    end)
    connect(World.DescendantAdded, function(object)
        if object:IsA('Beam') then task.defer(function() if state.Alive then inspectBeam(object) end end) end
    end)
    local elapsed = 0
    connect(RunService.Heartbeat, function(dt)
        local time = now()
        if not config.Whitelist.Enabled then state.Whitelist = {} end
        if state.FiringSource == 'Triggerbot' then
            local ammo = childValue(state.FiringTool, 'Ammo')
            if not enabled('Triggerbot') or (type(ammo) == 'number' and ammo <= 0) then releaseShotInput() end
        end
        if (state.ShotRelease or state.AutomatedTool) and (time >= state.DeactivateAt or not localHumanoid or localHumanoid.Health <= 0) then releaseShotInput() end
        elapsed = elapsed + dt
        if elapsed >= 1 / 30 then
            elapsed = elapsed % (1 / 30)
            for _, record in pairs(state.Records) do
                if record.root and Core.finiteVector(record.root.Position) then Core.sample(record.history, record.root.Position, time) end
                if config.Misc.Prefire.Enabled then observeAmmo(record) end
            end
            updateAim()
            if not typing() then automaticFire(time) end
            refreshPacket()
        end
        if (state.ShotRelease or state.AutomatedTool) and time >= state.DeactivateAt then releaseShotInput() end
        if state.PendingMacro and (not macroEnabled() or time > state.PendingMacro.expires) then state.PendingMacro = nil end
        macroStep(time); antiFling(); restoreBeams(false)
    end)
    RunService:BindToRenderStep(renderName, Enum.RenderPriority.Camera.Value + 1, function(dt)
        if not state.Alive or not captureView() then return end
        local point = state.Points['Aim Assist']
        if point and enabled('Aim Assist') and not typing() and config['Aim Assist'].Follow == 'Camera' then
            local offset = point - camera.CFrame.Position
            if offset.Magnitude > 0.01 then
                camera.CFrame = camera.CFrame:Lerp(CFrame.lookAt(camera.CFrame.Position, point), Core.alpha(config['Aim Assist'].Smoothness, dt))
            end
        end
        local ok, reason = pcall(drawFov)
        if not ok then warnOnce('draw-fov', tostring(reason)) end
        drawPlayers(now())
    end)
    -- Intro is bundled locally; no second downloaded script and no exposed intro options.
    if not environment.__neoperroIntroSeenV1 then
        environment.__neoperroIntroSeenV1 = true
        state.Intro = playIntro()
    end
    local panic = config.Misc.Panic.Keybind
    print('[neoperro] v' .. state.Version .. ' loaded for ' .. supported[game.PlaceId]
        .. '. ' .. (config.Misc.Panic.Enabled and (tostring(panic[panic[3] == 'Mouse' and 2 or 1]) .. ' = panic/unload.') or 'Panic key disabled.'))
end

local ok, reason = xpcall(start, debug.traceback)
if not ok then state:Destroy('startup-error'); error('[neoperro] ' .. tostring(reason), 0) end
return state
